package modele;

public class Joueur extends Personnage{
	public Joueur(){
		this.setNom("Joueur 1");
		this.setPositionX(0);
		this.setPositionY(0);
		//this.setVie(vie);
	}

}
