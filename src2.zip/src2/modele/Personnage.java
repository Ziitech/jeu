package modele;

public class Personnage extends Entite implements Mobilite{

	private String nom;
	
	public Personnage(){
		this.nom = null;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	@Override
	public void avancer() {
		this.setPositionX(this.getPositionX()+5);
	}

	@Override
	public void reculer() {
		this.setPositionX(this.getPositionX()-5);
	}

	@Override
	public void sauter() {
		this.setPositionY(this.getPositionY()+5);
	}

	@Override
	public void descendre() {
		this.setPositionY(this.getPositionY()-5);
	}

}
