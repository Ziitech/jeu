package modele;

public class IA {

}
