package modele;

public class Entite extends Thread implements Runnable {
	private int vie;
	private int positionX;
	private int positionY;
	
	public Entite(){
		this.vie = 100;
		this.positionX = 0;
		this.positionY = 0;
		
	}
	
	public int getVie() {
		return vie;
	}
	public void setVie(int vie) {
		this.vie = vie;
	}
	public int getPositionX() {
		return positionX;
	}
	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}
	public int getPositionY() {
		return positionY;
	}
	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}
	@Override
	public void interrupt() {
		// TODO Auto-generated method stub
		super.interrupt();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
	@Override
	public synchronized void start() {
		// TODO Auto-generated method stub
		super.start();
	}
	
	

}
