package modele;

public interface Mobilite {
	public void avancer();
	public void reculer();
	public void sauter();
	public void descendre();

}
