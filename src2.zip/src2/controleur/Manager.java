package controleur;

import java.util.List;
import java.util.Vector;

import modele.IA;
import modele.Joueur;
import modele.Carte;
import vue.Vue;

public class Manager {
	private static Manager instance = new Manager();
	private Vue vue;
	private List<Joueur> joueur;
	private IA ia;
	private Carte map;
	private Thread affichage;

	/**
	 * Constructeur de Manager
	 */
	private Manager() {
		this.vue = null;
		this.joueur = new Vector<Joueur>();
		this.ia = new IA();
		//affichage = new Thread(this);
	}

	/**
	 * Methode qui permet de recuperer une instance unique de Manager
	 * @return instance
	 */
	public static Manager getInstance() {
		return instance;
	}

	public Vue getVue() {
		return vue;
	}

	public void setVue(Vue vue) {
		if(this.vue == null){
			this.vue = vue;
			map = new Carte(this.vue.getFrameWidth(),this.vue.getFrameHeight());
		}
		
	}
	

	public synchronized void startGame() {
		setJoueur(new Joueur());
		//affichage.start();
	}
	
	private void drawMap() {
		int w = map.getWidth();
		int h = map.getHeight();
		int size = map.getTileSize();
		
		for(int y = 0 ; y < h ; y++) {
			int yp = y * size;
			
			for(int x = 0 ; x < w ; x++) {
				int xp = x * size;
				
				vue.drawTiles(xp,yp,size,map.getTilesAt(x, y));
			}
		}
	}

	public List<Joueur> getJoueur() {
		return joueur;
	}

	public void setJoueur(Joueur joueur) {
		this.joueur.add(joueur);
	}
	
	

}
